export class SetAlertDto {
    chain: string;
    dollar: number;
    email: string;
}
